package com.example.battery_planner;

import android.content.Context;

public class ActivityItem {
    private String name;
    private int hours;
    private int minutes;
    private int batteryUsage;
    private String presetKey;
    private double usageValue;
    private String usageUnit;

    public ActivityItem(String name, int hours, int minutes, int batteryUsage) {
        this(name, hours, minutes, batteryUsage, null);
    }

    public ActivityItem(String name, int hours, int minutes, int batteryUsage, String presetKey) {
        this.name = name;
        this.hours = hours;
        this.minutes = minutes;
        this.batteryUsage = batteryUsage;
        this.presetKey = presetKey;
        this.usageValue = batteryUsage;
        this.usageUnit = "mah";
    }

    public String getPresetKey() { return presetKey; }
    public String getName() { return name; }
    public int getHours() { return hours; }
    public int getMinutes() { return minutes; }
    public int getBatteryUsage() { return batteryUsage; }

    public ActivityItem(String name, int hours, int minutes, double usageValue, String usageUnit, String presetKey) {
        this.name = name;
        this.hours = hours;
        this.minutes = minutes;
        this.batteryUsage = (int) Math.round(usageValue);
        this.usageValue = usageValue;
        this.usageUnit = "percent".equals(usageUnit) ? "percent" : "mah";
        this.presetKey = presetKey;
    }

    public boolean isPercentUsage() { return "percent".equals(usageUnit); }
    public double getUsageValue() {
        return usageUnit == null ? batteryUsage : usageValue;
    }
    public double getUsageMah(double effectiveCapacityMah) {
        double value = getUsageValue();
        return isPercentUsage() ? value * effectiveCapacityMah / 100.0 : value;
    }

    public String getLocalizedName(Context context) {
        String key = presetKey;
        if (key == null && name != null) {
            switch (name.trim().toLowerCase(java.util.Locale.ROOT)) {
                case "gaming": case "játék": key = "gaming"; break;
                case "video": case "videó": key = "video"; break;
                case "social media": case "közösségi média": key = "social"; break;
                case "music": case "zene": key = "music"; break;
                case "browsing": case "böngészés": key = "browsing"; break;
                case "navigation": case "navigáció": key = "navigation"; break;
            }
        }
        if (key == null) return name == null ? "" : name;
        switch (key) {
            case "gaming": return context.getString(R.string.activity_gaming);
            case "video": return context.getString(R.string.activity_video);
            case "social": return context.getString(R.string.activity_social);
            case "music": return context.getString(R.string.activity_music);
            case "browsing": return context.getString(R.string.activity_browsing);
            case "navigation": return context.getString(R.string.activity_navigation);
            default: return name == null ? "" : name;
        }
    }
}
