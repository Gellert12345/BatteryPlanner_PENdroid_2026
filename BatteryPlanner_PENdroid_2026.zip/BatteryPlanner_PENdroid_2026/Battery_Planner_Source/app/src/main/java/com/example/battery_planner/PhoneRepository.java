
package com.example.battery_planner;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class PhoneRepository {
    private static final String TAG = "PhoneRepository";
    private static final String PREFS_NAME = "BatteryPlanner";
    private static final String CUSTOM_PHONES_KEY = "customPhones";

    private final Context context;
    private final Gson gson = new Gson();
    private final Map<Integer, Phone> phoneMap = new LinkedHashMap<>();
    private final List<Phone> customPhones = new ArrayList<>();

    public PhoneRepository(Context context) {
        this.context = context.getApplicationContext();
        loadPhonesFromJson();
        loadCustomPhones();
    }

    private void loadPhonesFromJson() {
        phoneMap.clear();

        try (InputStream input = context.getAssets().open("database.json");
             Reader reader = new InputStreamReader(
                     input,
                     java.nio.charset.StandardCharsets.UTF_8
             )) {

            Type type = new TypeToken<List<Phone>>() {}.getType();
            List<Phone> phones = gson.fromJson(reader, type);

            if (phones != null) {
                for (Phone phone : phones) {
                    if (phone != null) {
                        phoneMap.put(phone.getId(), phone);
                    }
                }
            }

            Log.d(TAG, "Loaded phones: " + phoneMap.size());

        } catch (Exception e) {
            Log.e(TAG, "Failed to load database.json", e);
        }
    }

    private void loadCustomPhones() {
        customPhones.clear();

        SharedPreferences preferences = context.getSharedPreferences(
                PREFS_NAME,
                Context.MODE_PRIVATE
        );

        String json = preferences.getString(CUSTOM_PHONES_KEY, "[]");

        try {
            Type type = new TypeToken<List<Phone>>() {}.getType();
            List<Phone> savedPhones = gson.fromJson(json, type);

            if (savedPhones != null) {
                for (Phone phone : savedPhones) {
                    if (phone != null) {
                        customPhones.add(phone);
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to load custom phones", e);
        }
    }

    private void saveCustomPhones() {
        String json = gson.toJson(customPhones);

        context.getSharedPreferences(
                PREFS_NAME,
                Context.MODE_PRIVATE
        ).edit().putString(CUSTOM_PHONES_KEY, json).apply();
    }

    public List<Phone> getDefaultPhones() {
        List<Phone> phones = new ArrayList<>(phoneMap.values());

        Collections.sort(phones, Comparator.comparing(
                Phone::getName,
                String.CASE_INSENSITIVE_ORDER
        ));

        return phones;
    }

    public List<Phone> getCustomPhones() {
        return new ArrayList<>(customPhones);
    }

    public Phone findById(int id) {
        return phoneMap.get(id);
    }

    public Phone findPhoneByName(String name) {
        if (name == null) {
            return null;
        }

        String target = name.trim();

        for (Phone phone : customPhones) {
            if (phone.getName().equalsIgnoreCase(target)) {
                return phone;
            }
        }

        for (Phone phone : phoneMap.values()) {
            if (phone.getName().equalsIgnoreCase(target)) {
                return phone;
            }
        }

        return null;
    }

    public List<Phone> searchByName(String query) {
        List<Phone> results = new ArrayList<>();

        String search = query == null
                ? ""
                : query.trim().toLowerCase(Locale.ROOT);

        for (Phone phone : customPhones) {
            if (phone.getName().toLowerCase(Locale.ROOT).contains(search)) {
                results.add(phone);
            }
        }

        for (Phone phone : phoneMap.values()) {
            if (phone.getName().toLowerCase(Locale.ROOT).contains(search)) {
                results.add(phone);
            }
        }

        return results;
    }

    public Map<Integer, Phone> getAllPhones() {
        return Collections.unmodifiableMap(phoneMap);
    }

    public void addCustomPhone(Phone phone) {
        if (phone == null || phone.getName().trim().isEmpty()
                || phone.getCapacityMah() <= 0) {
            return;
        }

        for (int i = 0; i < customPhones.size(); i++) {
            if (customPhones.get(i).getName()
                    .equalsIgnoreCase(phone.getName())) {
                customPhones.set(i, phone);
                saveCustomPhones();
                return;
            }
        }

        customPhones.add(phone);
        saveCustomPhones();
    }

    public void deleteCustomPhone(Phone phone) {
        if (phone == null) {
            return;
        }

        customPhones.removeIf(existing ->
                existing.getName().equalsIgnoreCase(phone.getName())
        );

        saveCustomPhones();
    }

    public Phone findCurrentDevice() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;

        if (model == null || model.trim().isEmpty()) {
            return null;
        }

        String modelLower = model.toLowerCase(Locale.ROOT).trim();
        String manufacturerLower = manufacturer == null
                ? ""
                : manufacturer.toLowerCase(Locale.ROOT).trim();

        List<Phone> allPhones = new ArrayList<>(customPhones);
        allPhones.addAll(phoneMap.values());

        for (Phone phone : allPhones) {
            String phoneName = phone.getName()
                    .toLowerCase(Locale.ROOT).trim();

            if (phoneName.equals(modelLower)
                    || phoneName.equals(
                    (manufacturerLower + " " + modelLower).trim()
            )) {
                return phone;
            }
        }

        for (Phone phone : allPhones) {
            String phoneModel = phone.getModel();

            if (phoneModel != null
                    && phoneModel.toLowerCase(Locale.ROOT)
                    .trim().equals(modelLower)) {
                return phone;
            }
        }

        return null;
    }
}